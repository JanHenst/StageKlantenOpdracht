
      <footer class="footer">
          <h3>Jenneke & Sanne</h3>
          <div class="contactInfo">
              <h3>Contact</h3>
              <a target=”_blank” href="mailto:jennekeensanne@gmail.com">jennekeensanne@gmail.com</a>
              <p></p>
              &copy;2020 Jenneke & Sanne
          </div><a target=”_blank” href="https://facebook.com/liedjesduo.nl/"><svg class="facebook-footer">
              <use xlink:href='<?php echo get_template_directory_uri()?>/plaatjes/header/facebook.svg#facebook'></use>
          </svg><a/>
      </footer>

    </div>
  </body>
</html>





