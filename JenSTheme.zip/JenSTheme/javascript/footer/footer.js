let doneer = document.getElementById('doneer');

doneer.addEventListener('click',function () {
    console.log("test");
    window.location.href ='https://www.paypal.com/donate?hosted_button_id=ZPTYTJSDTJUWC';
});