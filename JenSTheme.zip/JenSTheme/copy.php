<?php
copy("test.png","plaatjes/carousel/carouselContent/test.png");
?>