<?php
/**
 * Created by PhpStorm.
 * User: florianmac
 * Date: 04/02/2021
 * Time: 11:27
 */
$servername = "localhost";
$username = "floortje";
$password = 'tV5buPo7z8qj';
$database="SpeelLijst";
